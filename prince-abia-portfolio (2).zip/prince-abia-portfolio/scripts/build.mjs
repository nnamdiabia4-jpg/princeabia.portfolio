// Copies the static site into dist/ so Vercel always finds its output folder.
// Works whether the site files sit in public/, in the project root, or in a nested folder.
import { existsSync, readdirSync, statSync, rmSync, mkdirSync, cpSync, readFileSync } from 'node:fs';
import { join, relative } from 'node:path';

const root = process.cwd();
const OUT = join(root, 'dist');
const SKIP = new Set(['node_modules', '.git', '.vercel', 'dist', 'scripts']);

function findIndex(dir, depth = 0) {
  if (existsSync(join(dir, 'index.html'))) return dir;
  if (depth > 3) return null;
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name) || name.startsWith('.')) continue;
    const p = join(dir, name);
    if (statSync(p).isDirectory()) {
      const hit = findIndex(p, depth + 1);
      if (hit) return hit;
    }
  }
  return null;
}

function tree(dir, depth = 0, lines = []) {
  if (depth > 2) return lines;
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const p = join(dir, name);
    lines.push('  '.repeat(depth) + '- ' + name);
    if (statSync(p).isDirectory()) tree(p, depth + 1, lines);
  }
  return lines;
}

const src = existsSync(join(root, 'public', 'index.html')) ? join(root, 'public') : findIndex(root);
if (!src) {
  console.error('Build failed: no index.html found in this repository.');
  console.error('Files that Vercel received:\n' + tree(root).join('\n'));
  console.error('Make sure index.html, covers/ and vendor/ were committed and pushed.');
  process.exit(1);
}

rmSync(OUT, { recursive: true, force: true });
mkdirSync(OUT, { recursive: true });
for (const name of readdirSync(src)) {
  if (SKIP.has(name) || name.startsWith('.')) continue;
  if (src === root && ['package.json', 'package-lock.json', 'vercel.json', 'README.md'].includes(name)) continue;
  cpSync(join(src, name), join(OUT, name), { recursive: true });
}

// Report any images the page references that were not committed.
const html = readFileSync(join(OUT, 'index.html'), 'utf8');
const refs = [...new Set(html.match(/(?:covers|vendor)\/[\w.-]+/g) || [])];
const missing = refs.filter(r => !existsSync(join(OUT, r)));
console.log(`Copied site from ./${relative(root, src) || '.'} to ./dist (${refs.length - missing.length}/${refs.length} assets found).`);
if (missing.length) console.warn('Warning: these files are referenced but missing from the repository:\n  ' + missing.join('\n  '));
